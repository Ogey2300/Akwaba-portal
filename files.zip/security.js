// backend/middleware/security.js
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import mongoSanitize from 'mongo-sanitize';

// Helmet for security headers with CSP configured (not disabled)
export const securityHeaders = helmet({
  hsts: { maxAge: 31536000 },
  frameguard: { action: 'deny' },
  contentSecurityPolicy: { // ✅ Fixed: configured instead of disabled
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'"],
      imgSrc: ["'self'", "data:"],
      connectSrc: ["'self'"],
      fontSrc: ["'self'"],
      objectSrc: ["'none'"],
      frameAncestors: ["'none'"]
    }
  }
});

// Rate limiters
export const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 5,
  message: { error: 'Too many login attempts. Please try again after 15 minutes.' },
  standardHeaders: true,
  legacyHeaders: false
});

export const generalLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 100,
  standardHeaders: true,
  legacyHeaders: false
});

// Input sanitization - prevent NoSQL injection
export const sanitizeInputs = (req, res, next) => {
  if (req.body) req.body = mongoSanitize(req.body);   // ✅ Fixed: was mongoSanitize()(req.body)
  if (req.query) req.query = mongoSanitize(req.query); // ✅ Fixed: was mongoSanitize()(req.query)
  if (req.params) req.params = mongoSanitize(req.params);
  next();
};

// CSRF protection
export const csrfProtection = (req, res, next) => {
  if (['POST', 'PUT', 'DELETE', 'PATCH'].includes(req.method)) {
    const token = req.headers['x-csrf-token'];
    if (!token || token !== req.cookies.csrfToken) {
      return res.status(403).json({ error: 'CSRF validation failed' });
    }
  }
  next();
};
