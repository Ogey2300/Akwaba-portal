/**
 * COMPREHENSIVE INPUT VALIDATION
 */

import validator from 'validator';

// Schema with security constraints
export const registrationPage1Schema = {
  surname: {
    type: 'string',
    required: true,
    minLength: 2,
    maxLength: 50,
    pattern: /^[a-zA-Z\s'-]+$/,
    description: 'Surname'
  },
  firstName: {
    type: 'string',
    required: true,
    minLength: 2,
    maxLength: 50,
    pattern: /^[a-zA-Z\s'-]+$/,
    description: 'First name'
  },
  email: {
    type: 'email',
    required: true,
    maxLength: 100,
    description: 'Email'
  },
  phone: {
    type: 'phone',
    required: true,
    pattern: /^(\+234|0)[0-9]{10}$/,
    description: 'Phone (Nigerian format)'
  },
  password: {
    type: 'password',
    required: true,
    minLength: 8,
    maxLength: 128,
    description: 'Password'
  }
};

export function validateFormData(data, schema) {
  const errors = {};
  const sanitized = {};

  Object.keys(schema).forEach(field => {
    const fieldSchema = schema[field];
    const value = data[field];

    // Required check
    if (fieldSchema.required && !value) {
      errors[field] = `${fieldSchema.description} is required`;
      return;
    }

    // Type-specific validation
    if (value) {
      if (fieldSchema.type === 'email') {
        if (!validator.isEmail(value)) {
          errors[field] = 'Invalid email format';
        } else {
          sanitized[field] = value.toLowerCase().trim();
        }
      } else if (fieldSchema.type === 'phone') {
        if (!value.match(fieldSchema.pattern)) {
          errors[field] = 'Invalid phone format (use +234 or 0)';
        } else {
          sanitized[field] = normalizePhone(value); // ✅ Fixed: was this.normalizePhone
        }
      } else if (fieldSchema.type === 'password') {
        const passwordError = validatePassword(value); // ✅ Fixed: was this.validatePassword
        if (passwordError) {
          errors[field] = passwordError;
        } else {
          sanitized[field] = value;
        }
      } else if (fieldSchema.type === 'string') {
        if (value.length < fieldSchema.minLength || value.length > fieldSchema.maxLength) {
          errors[field] = `Must be ${fieldSchema.minLength}-${fieldSchema.maxLength} characters`;
        } else if (fieldSchema.pattern && !fieldSchema.pattern.test(value)) {
          errors[field] = 'Invalid format';
        } else {
          sanitized[field] = sanitizeString(value); // ✅ Fixed: was this.sanitizeString
        }
      }
    }
  });

  return { success: Object.keys(errors).length === 0, errors, data: sanitized };
}

/**
 * Password validation - STRONG POLICY
 */
function validatePassword(password) {
  if (password.length < 8) return 'Minimum 8 characters';
  if (!/[a-z]/.test(password)) return 'Must contain lowercase letters';
  if (!/[A-Z]/.test(password)) return 'Must contain uppercase letters';
  if (!/\d/.test(password)) return 'Must contain numbers';
  if (!/[@$!%*?&]/.test(password)) return 'Must contain special characters: @$!%*?&';
  if (/(.)\1{2,}/.test(password)) return 'No repeating characters allowed';

  return null; // Valid
}

/**
 * File validation
 */
export function validateFile(file, maxSize = 5 * 1024 * 1024) {
  const allowed = ['image/jpeg', 'image/png', 'application/pdf'];
  const extensions = ['jpg', 'jpeg', 'png', 'pdf'];

  if (!file) return 'No file selected';
  if (file.size > maxSize) return 'File too large (max 5MB)';
  if (!allowed.includes(file.type)) return 'Invalid file type (jpg, png, pdf only)';

  const ext = file.name.split('.').pop().toLowerCase();
  if (!extensions.includes(ext)) return 'Invalid extension';
  if (file.name.split('.').length > 2) return 'No double extensions allowed';

  return null;
}

/**
 * Sanitize string to prevent XSS
 * Strips HTML tags and encodes dangerous characters
 */
function sanitizeString(value) {
  return value
    .replace(/<[^>]*>/g, '')       // Remove HTML tags
    .replace(/&/g, '&amp;')        // Encode & first (must be first)
    .replace(/"/g, '&quot;')       // Encode quotes
    .replace(/'/g, '&#x27;')       // Encode single quotes
    .replace(/\//g, '&#x2F;')      // Encode forward slash
    .trim();
}

/**
 * Normalize phone number to E.164 format
 */
function normalizePhone(phone) {
  let cleaned = phone.replace(/\D/g, '');
  if (cleaned.startsWith('0')) {
    cleaned = '234' + cleaned.substring(1);
  } else if (!cleaned.startsWith('234')) {
    cleaned = '234' + cleaned;
  }
  return '+' + cleaned;
}
