// backend/app.js
import express from 'express';
import cors from 'cors';
import cookieParser from 'cookie-parser';
import authController from './controllers/authController.js'; // ✅ Fixed: was missing
import {
  loginLimiter,
  generalLimiter,
  securityHeaders,
  sanitizeInputs,
  csrfProtection
} from './middleware/security.js';

const app = express();

// Security headers (Helmet)
app.use(securityHeaders);

// CORS - only allow specified origins
app.use(cors({
  origin: process.env.ALLOWED_ORIGINS?.split(','),
  credentials: true // Required for httpOnly cookies
}));

// Parse cookies and JSON body
app.use(cookieParser());
app.use(express.json({ limit: '1mb' }));

// Sanitize inputs (NoSQL injection protection)
app.use(sanitizeInputs);

// CSRF protection on state-changing requests
app.use(csrfProtection);

// General rate limiting on all routes
app.use(generalLimiter);

// Routes
app.post('/api/v1/auth/login', loginLimiter, authController.login);
app.post('/api/v1/auth/register', authController.register);
app.post('/api/v1/auth/logout', authController.logout);
app.post('/api/v1/auth/refresh', authController.refresh);

export default app;
