/**
 * SECURE API CLIENT
 */
import SecureStorage from './storage.js';

class APIClient {
  constructor() {
    this.baseURL = process.env.REACT_APP_API_URL || 'http://localhost:3000/api/v1';
    this.timeout = 10000;
  }

  /**
   * Secure request with CSRF token
   * @param {string} endpoint
   * @param {object} options
   * @param {boolean} retry - Internal flag to prevent infinite 401 loop
   */
  async request(endpoint, options = {}, retry = true) { // ✅ Fixed: added retry flag
    try {
      const config = {
        method: options.method || 'GET',
        credentials: 'include', // ✅ Send httpOnly cookies automatically
        headers: {
          'Content-Type': 'application/json',
          'X-CSRF-Token': SecureStorage.getCSRFToken()
        }
      };

      // Add body if provided
      if (options.body) {
        if (options.body instanceof FormData) {
          delete config.headers['Content-Type']; // Let browser set multipart boundary
          config.body = options.body;
        } else {
          config.body = JSON.stringify(options.body);
        }
      }

      // Setup timeout
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), this.timeout);

      const response = await fetch(`${this.baseURL}${endpoint}`, {
        ...config,
        signal: controller.signal
      });

      clearTimeout(timeoutId);

      // Handle 401 - token expired, attempt refresh once only
      if (response.status === 401 && retry) { // ✅ Fixed: only retry once
        await this.refreshToken();
        return this.request(endpoint, options, false); // ✅ retry=false prevents loop
      }

      if (!response.ok) {
        const error = await response.json().catch(() => ({ error: { message: response.statusText } }));
        throw new Error(error.error?.message || response.statusText);
      }

      return response.json();
    } catch (error) {
      if (error.name === 'AbortError') {
        throw new Error('Request timed out. Please try again.');
      }
      throw new Error(error.message);
    }
  }

  async refreshToken() {
    const response = await fetch(`${this.baseURL}/auth/refresh`, {
      method: 'POST',
      credentials: 'include'
    });

    if (!response.ok) {
      window.location.href = '/login'; // Redirect to login if refresh fails
    }
  }

  // Auth endpoints
  async register(formData) {
    return this.request('/auth/register', {
      method: 'POST',
      body: formData
    });
  }

  async login(phone, password) {
    return this.request('/auth/login', {
      method: 'POST',
      body: { phone, password }
    });
  }

  async logout() {
    return this.request('/auth/logout', { method: 'POST' });
  }
}

export default new APIClient();
