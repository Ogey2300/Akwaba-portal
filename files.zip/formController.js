/**
 * OPTIMIZED FORM CONTROLLER
 */

import APIClient from './api.js';
import { validateFormData, registrationPage1Schema, validateFile } from './validation.js';
import SecureStorage from './storage.js';

class FormController {
  constructor() {
    this.currentPage = 1;
    this.isSubmitting = false;
    this.formData = { page1: {}, page2: {}, page3: {} };
    this.setupEventListeners();
  }

  setupEventListeners() {
    document.getElementById('form-page-1')?.addEventListener('submit', e => this.handlePage1(e));
    document.getElementById('form-page-2')?.addEventListener('submit', e => this.handlePage2(e));
    document.getElementById('form-page-3')?.addEventListener('submit', e => this.handlePage3(e));
    document.querySelector('#login-container form')?.addEventListener('submit', e => this.handleLogin(e));
  }

  async handlePage1(e) {
    e.preventDefault();
    const formData = {
      surname: document.getElementById('surname').value,
      firstName: document.getElementById('firstName').value,
      email: document.getElementById('email').value,
      phone: document.getElementById('phone').value,
      password: document.getElementById('password').value
    };

    const validation = validateFormData(formData, registrationPage1Schema);
    if (!validation.success) {
      this.displayErrors(validation.errors);
      return;
    }

    // Store validated data in memory only (password never goes to sessionStorage)
    this.formData.page1 = validation.data;
    SecureStorage.setFormDraft('page1', {
      surname: validation.data.surname,
      firstName: validation.data.firstName,
      email: validation.data.email,
      phone: validation.data.phone
      // ✅ password intentionally excluded from sessionStorage
    });

    this.showToast('✓ Saved', 'success');
    this.goToPage(2);
  }

  async handlePage2(e) {
    e.preventDefault();
    // Add page 2 field validation here when ready
    this.goToPage(3);
  }

  async handlePage3(e) {
    e.preventDefault();

    if (this.isSubmitting) return; // Prevent double submission

    const file = document.getElementById('receipt').files[0];
    const fileError = validateFile(file);
    if (fileError) {
      this.showToast(fileError, 'error');
      return;
    }

    // Build FormData for multipart submission
    const submitData = new FormData();
    submitData.append('surname', this.formData.page1.surname);
    submitData.append('firstName', this.formData.page1.firstName);
    submitData.append('email', this.formData.page1.email);
    submitData.append('phone', this.formData.page1.phone);
    submitData.append('password', this.formData.page1.password);
    submitData.append('docType', this.formData.page2.docType);
    submitData.append('roomPreference', this.formData.page2.roomPreference);
    submitData.append('receipt', file);

    this.isSubmitting = true;
    try {
      const response = await APIClient.register(submitData);
      this.showToast('✅ Registration complete! Check your email.', 'success');
      SecureStorage.clearFormDrafts();
      this.clearFormData();
      setTimeout(() => this.switchTab('login'), 2000);
    } catch (error) {
      this.showToast(error.message || 'Registration failed. Please try again.', 'error');
    } finally {
      this.isSubmitting = false;
    }
  }

  async handleLogin(e) {
    e.preventDefault();
    const phone = document.getElementById('loginPhone').value;
    const password = document.getElementById('loginPin').value;

    try {
      const response = await APIClient.login(phone, password);
      // Backend sets httpOnly cookie automatically — no token handling needed here
      this.showToast(`Welcome, ${response.user.firstName}!`, 'success');
      this.showDashboard(response.user);
    } catch (error) {
      this.showToast('Login failed. Check your phone and password.', 'error');
    }
  }

  clearFormData() {
    this.formData = { page1: {}, page2: {}, page3: {} };
  }

  goToPage(page) {
    document.querySelectorAll('[id^="form-page"]').forEach(el => el.classList.add('hidden'));
    document.getElementById(`form-page-${page}`).classList.remove('hidden');
    this.currentPage = page;
  }

  showToast(message, type = 'info') {
    const toast = document.createElement('div');
    toast.className = `toast toast--${type}`;
    toast.textContent = message;
    document.body.appendChild(toast);
    setTimeout(() => toast.remove(), 3000);
  }

  displayErrors(errors) {
    // Clear previous errors first
    document.querySelectorAll('[id$="-error"]').forEach(el => el.textContent = '');
    Object.entries(errors).forEach(([field, msg]) => {
      const el = document.getElementById(`${field}-error`);
      if (el) el.textContent = msg;
    });
  }

  switchTab(tab) {
    // Implement tab switching logic based on your HTML structure
    document.querySelectorAll('.tab-content').forEach(el => el.classList.add('hidden'));
    document.getElementById(`${tab}-container`)?.classList.remove('hidden');
  }

  showDashboard(user) {
    // Implement dashboard display logic
    console.log('Show dashboard for:', user);
  }
}

export default new FormController();
