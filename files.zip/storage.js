/**
 * SECURE STORAGE - Uses httpOnly Cookies
 */
class SecureStorage {
  /**
   * Get auth token from httpOnly cookie
   * Backend sets this automatically
   */
  getAuthToken() {
    // Browser doesn't allow JavaScript access to httpOnly cookies
    // This is handled automatically by fetch() with credentials: 'include'
    return 'httpOnly-cookie-handled-by-browser';
  }

  setAuthToken(token) {
    console.warn('⚠️ Backend must set httpOnly cookie, not frontend');
    // This should NEVER be called in production
  }

  clearAuthToken() {
    // Backend clears via Set-Cookie with Max-Age: 0
    // Nothing to do here
  }

  /**
   * Get CSRF token from meta tag
   */
  getCSRFToken() {
    return document.querySelector('meta[name="csrf-token"]')?.content;
  }

  /**
   * Store non-sensitive form data in sessionStorage
   * (cleared when browser tab closes)
   */
  setFormDraft(page, data) {
    // Remove sensitive fields
    const { password, ...safeData } = data;

    if (Object.keys(safeData).length > 0) {
      sessionStorage.setItem(`formDraft_${page}`, JSON.stringify(safeData));
    }
  }

  getFormDraft(page) {
    const data = sessionStorage.getItem(`formDraft_${page}`);
    return data ? JSON.parse(data) : null;
  }

  clearFormDrafts() {
    Object.keys(sessionStorage).forEach(key => {
      if (key.startsWith('formDraft_')) {
        sessionStorage.removeItem(key);
      }
    });
  }
}

export default new SecureStorage();
